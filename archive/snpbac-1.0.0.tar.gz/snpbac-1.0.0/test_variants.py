#!/usr/local/python

from call_variants import VariantCaller

final_results_directory = "butts/snpbac_final_results/"
reference = "bacillus_cytotoxicus_NVH_391_98_TYPE_STRAIN.fna"
threads = str(4)
minq = 20

call_variants = VariantCaller(
	final_results_directory = final_results_directory,
	reference = reference,
	threads = threads,
	minq = minq)

bam_names = call_variants.gather_bamfiles(final_results_directory)
print(bam_names)

call_variants.freebayes_variant_caller(final_results_directory, reference, threads, bam_names)

call_variants.filter_variants(final_results_directory, minq)
